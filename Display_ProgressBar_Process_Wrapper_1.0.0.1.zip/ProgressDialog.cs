﻿using System;
using System.Windows.Forms;

namespace ProgressBar
{
    public partial class ProgressDialog : Form
    {
        public ProgressDialog()
        {
            InitializeComponent();
        }

        public void UpdateProgress(int progress)
        {
            if (progressBar.InvokeRequired)
                progressBar.BeginInvoke(new Action(() => progressBar.Value = progress));
            else
                progressBar.Value = progress;
            
        }

        public void SetIndeterminate(bool isIndeterminate)
        {
            if (progressBar.InvokeRequired)
            {
                progressBar.BeginInvoke(new Action(() =>
                    {
                        if (isIndeterminate)
                            progressBar.Style = ProgressBarStyle.Marquee;
                        else
                            progressBar.Style = ProgressBarStyle.Blocks;
                    }
                ));
            }
            else
            {
                if (isIndeterminate)
                    progressBar.Style = ProgressBarStyle.Marquee;
                else
                    progressBar.Style = ProgressBarStyle.Blocks;
            }
        }
    }
}
