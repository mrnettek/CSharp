﻿using System;
using System.Windows.Forms;
using System.Threading;

namespace ProgressBar
{
    public partial class Form1 : Form
    {
        private bool isProcessRunning = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Hide(); // hide initial form

            if (isProcessRunning)
            {
                // MessageBox.Show("Process is running...");
                return;
            }

            ProgressDialog progressBar = new ProgressDialog();            

            // Task 1 background thread
            // add your setup or install EXE here
            Thread bgThread = new Thread(
                new ThreadStart(() =>
                {          
                    isProcessRunning = true;

                    // Progress Bar Control
                    // begin
                    for (int n = 0; n < 20; n++)
                    {
                        // Add your custom code here
                        Thread.Sleep(1000);
                        progressBar.UpdateProgress(n);
                    }

                    for (int n = 21; n < 100; n++)
                    {
                        // Add your custom code here
                        Thread.Sleep(100);
                        progressBar.UpdateProgress(n);
                    }
                    // end

                    Thread.Sleep(500);

                    if (progressBar.InvokeRequired)
                        progressBar.BeginInvoke(new Action(() => progressBar.Close()));

                    isProcessRunning = false;
                                        
                }
            ));

            // Start Process
            bgThread.Start();

            // Start Progress Bar
            progressBar.ShowDialog();

            // add other post thread code here

            this.Close(); // close form            
        }
     
    }
}
